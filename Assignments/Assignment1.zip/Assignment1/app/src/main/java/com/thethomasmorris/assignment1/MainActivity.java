package com.thethomasmorris.assignment1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    int xWins = 0;
    int oWins = 0;
    int ties = 0;
    int turns = 0;
    Button[][] buttons = new Button[3][3]; //2D array of buttons
    boolean xTurn = true;

    //method to check for winner
    boolean getWin(){

        String[][] board = new String[3][3];

        //fill up the 2d string array with the text from our buttons
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++)
                board[i][j] = buttons[i][j].getText().toString();

        //scan the rows for a win
        for (int i = 0; i < 3; i++)
            if(board[i][0].equals(board[i][1]) && board[i][0].equals(board[i][2]) && !(board[i][0].equals(""))) {
                reset();
                return true;
            }

        //scan the columns for a win
        for (int i = 0; i < 3; i++)
            if(board[0][i].equals(board[1][i]) && board[0][i].equals(board[2][i]) && !(board[0][i].equals(""))) {
                reset();
                return true;
            }

        //check first diagonal
        if(board[0][0].equals(board[1][1]) && board[0][0].equals(board[2][2]) && !(board[0][0].equals(""))) {
            reset();
            return true;
        }

        //check second diagonal
        if(board[0][2].equals(board[1][1]) && board[0][2].equals(board[2][0]) && !(board[0][2].equals(""))) {
            reset();
            return true;
        }

        //there is not a winner yet
        return false;
    }

    //method to display scores
    void scores(){

        //create a textview to display the wins and ties
        TextView tvX = findViewById(R.id.tv_xwin);
        TextView tvO = findViewById(R.id.tv_owin);
        TextView tvT = findViewById(R.id.tv_ties);

        tvX.setText("X Wins: "+xWins);
        tvO.setText("O Wins: "+oWins);
        tvT.setText("Ties: "+ties);
    }

    //method to reset board
    void reset() {
        //clear out all of the buttons
        buttons[0][0].setText("");
        buttons[0][1].setText("");
        buttons[0][2].setText("");
        buttons[1][0].setText("");
        buttons[1][1].setText("");
        buttons[1][2].setText("");
        buttons[2][0].setText("");
        buttons[2][1].setText("");
        buttons[2][2].setText("");

        //reset xTurn
        xTurn = true;

        //reset turns
        turns = 0;
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //set up the buttons
        buttons[0][0] = findViewById(R.id.btn_00);
        buttons[0][1] = findViewById(R.id.btn_01);
        buttons[0][2] = findViewById(R.id.btn_02);
        buttons[1][0] = findViewById(R.id.btn_10);
        buttons[1][1] = findViewById(R.id.btn_11);
        buttons[1][2] = findViewById(R.id.btn_12);
        buttons[2][0] = findViewById(R.id.btn_20);
        buttons[2][1] = findViewById(R.id.btn_21);
        buttons[2][2] = findViewById(R.id.btn_22);

        buttons[0][0].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(xTurn) {
                    //check if the button is empty
                    if (!buttons[0][0].getText().toString().equals(""))
                        return; //end the call if the spot is take

                    //set the players choice & check if they won
                    buttons[0][0].setText("X");

                    //check for win
                    if (getWin()) {
                        if (xTurn)
                            xWins++;
                        else
                            oWins++;
                        scores(); //update scores
                        reset(); //reset board
                    } else if (turns == 9) {
                        ties++;
                        scores();
                        reset();
                    } else
                        xTurn = !xTurn;

                    //increase turn count
                    turns++;
                }

                if(!xTurn){
                    //create rng for row & col
                    Random rngRow = new Random();
                    Random rngCol = new Random();

                    //make sure the computer's choice is not taken
                    while (buttons[rngRow.nextInt(3)][rngCol.nextInt(3)].getText().toString().equals("X")) {
                        rngRow = new Random();
                        rngCol = new Random();
                    }

                    //assign the computer choice
                    buttons[rngRow.nextInt(3)][rngCol.nextInt(3)].setText("O");

                    //check for win
                    if (getWin()) {
                        if (xTurn)
                            xWins++;
                        else
                            oWins++;
                        scores(); //update scores
                        reset(); //reset board
                    } else if (turns == 9) {
                        ties++;
                        scores();
                        reset();
                    } else
                        xTurn = !xTurn;

                    //increase turn count
                    turns++;
                }
            }
        });

        buttons[0][1].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(xTurn) {
                    //check if the button is empty
                    if (!buttons[0][1].getText().toString().equals(""))
                        return; //end the call if the spot is take

                    //set the players choice & check if they won
                    buttons[0][1].setText("X");

                    //check for win
                    if (getWin()) {
                        if (xTurn)
                            xWins++;
                        else
                            oWins++;
                        scores(); //update scores
                        reset(); //reset board
                    } else if (turns == 9) {
                        ties++;
                        scores();
                        reset();
                    } else
                        xTurn = !xTurn;

                    //increase turn count
                    turns++;
                }

                if(!xTurn){
                    //create rng for row & col
                    Random rngRow = new Random();
                    Random rngCol = new Random();

                    //make sure the computer's choice is not taken
                    while (buttons[rngRow.nextInt(3)][rngCol.nextInt(3)].getText().toString().equals("X")) {
                        rngRow = new Random();
                        rngCol = new Random();
                    }

                    //assign the computer choice
                    buttons[rngRow.nextInt(3)][rngCol.nextInt(3)].setText("O");

                    //check for win
                    if (getWin()) {
                        if (xTurn)
                            xWins++;
                        else
                            oWins++;
                        scores(); //update scores
                        reset(); //reset board
                    } else if (turns == 9) {
                        ties++;
                        scores();
                        reset();
                    } else
                        xTurn = !xTurn;

                    //increase turn count
                    turns++;
                }
            }
        });


        buttons[0][2].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(xTurn) {
                    //check if the button is empty
                    if (!buttons[0][2].getText().toString().equals(""))
                        return; //end the call if the spot is take

                    //set the players choice & check if they won
                    buttons[0][2].setText("X");

                    //check for win
                    if (getWin()) {
                        if (xTurn)
                            xWins++;
                        else
                            oWins++;
                        scores(); //update scores
                        reset(); //reset board
                    } else if (turns == 9) {
                        ties++;
                        scores();
                        reset();
                    } else
                        xTurn = !xTurn;

                    //increase turn count
                    turns++;
                }

                if(!xTurn){
                    //create rng for row & col
                    Random rngRow = new Random();
                    Random rngCol = new Random();

                    //make sure the computer's choice is not taken
                    while (buttons[rngRow.nextInt(3)][rngCol.nextInt(3)].getText().toString().equals("X")) {
                        rngRow = new Random();
                        rngCol = new Random();
                    }

                    //assign the computer choice
                    buttons[rngRow.nextInt(3)][rngCol.nextInt(3)].setText("O");

                    //check for win
                    if (getWin()) {
                        if (xTurn)
                            xWins++;
                        else
                            oWins++;
                        scores(); //update scores
                        reset(); //reset board
                    } else if (turns == 9) {
                        ties++;
                        scores();
                        reset();
                    } else
                        xTurn = !xTurn;

                    //increase turn count
                    turns++;
                }
            }
        });

        buttons[1][0].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(xTurn) {
                    //check if the button is empty
                    if (!buttons[1][0].getText().toString().equals(""))
                        return; //end the call if the spot is take

                    //set the players choice & check if they won
                    buttons[1][0].setText("X");

                    //check for win
                    if (getWin()) {
                        if (xTurn)
                            xWins++;
                        else
                            oWins++;
                        scores(); //update scores
                        reset(); //reset board
                    } else if (turns == 9) {
                        ties++;
                        scores();
                        reset();
                    } else
                        xTurn = !xTurn;

                    //increase turn count
                    turns++;
                }

                if(!xTurn){
                    //create rng for row & col
                    Random rngRow = new Random();
                    Random rngCol = new Random();

                    //make sure the computer's choice is not taken
                    while (buttons[rngRow.nextInt(3)][rngCol.nextInt(3)].getText().toString().equals("X")) {
                        rngRow = new Random();
                        rngCol = new Random();
                    }

                    //assign the computer choice
                    buttons[rngRow.nextInt(3)][rngCol.nextInt(3)].setText("O");

                    //check for win
                    if (getWin()) {
                        if (xTurn)
                            xWins++;
                        else
                            oWins++;
                        scores(); //update scores
                        reset(); //reset board
                    } else if (turns == 9) {
                        ties++;
                        scores();
                        reset();
                    } else
                        xTurn = !xTurn;

                    //increase turn count
                    turns++;
                }
            }
        });

        buttons[1][1].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(xTurn) {
                    //check if the button is empty
                    if (!buttons[1][1].getText().toString().equals(""))
                        return; //end the call if the spot is take

                    //set the players choice & check if they won
                    buttons[1][1].setText("X");

                    //check for win
                    if (getWin()) {
                        if (xTurn)
                            xWins++;
                        else
                            oWins++;
                        scores(); //update scores
                        reset(); //reset board
                    } else if (turns == 9) {
                        ties++;
                        scores();
                        reset();
                    } else
                        xTurn = !xTurn;

                    //increase turn count
                    turns++;
                }

                if(!xTurn){
                    //create rng for row & col
                    Random rngRow = new Random();
                    Random rngCol = new Random();

                    //make sure the computer's choice is not taken
                    while (buttons[rngRow.nextInt(3)][rngCol.nextInt(3)].getText().toString().equals("X")) {
                        rngRow = new Random();
                        rngCol = new Random();
                    }

                    //assign the computer choice
                    buttons[rngRow.nextInt(3)][rngCol.nextInt(3)].setText("O");

                    //check for win
                    if (getWin()) {
                        if (xTurn)
                            xWins++;
                        else
                            oWins++;
                        scores(); //update scores
                        reset(); //reset board
                    } else if (turns == 9) {
                        ties++;
                        scores();
                        reset();
                    } else
                        xTurn = !xTurn;

                    //increase turn count
                    turns++;
                }
            }
        });

        buttons[1][2].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(xTurn) {
                    //check if the button is empty
                    if (!buttons[1][2].getText().toString().equals(""))
                        return; //end the call if the spot is take

                    //set the players choice & check if they won
                    buttons[1][2].setText("X");

                    //check for win
                    if (getWin()) {
                        if (xTurn)
                            xWins++;
                        else
                            oWins++;
                        scores(); //update scores
                        reset(); //reset board
                    } else if (turns == 9) {
                        ties++;
                        scores();
                        reset();
                    } else
                        xTurn = !xTurn;

                    //increase turn count
                    turns++;
                }

                if(!xTurn){
                    //create rng for row & col
                    Random rngRow = new Random();
                    Random rngCol = new Random();

                    //make sure the computer's choice is not taken
                    while (buttons[rngRow.nextInt(3)][rngCol.nextInt(3)].getText().toString().equals("X")) {
                        rngRow = new Random();
                        rngCol = new Random();
                    }

                    //assign the computer choice
                    buttons[rngRow.nextInt(3)][rngCol.nextInt(3)].setText("O");

                    //check for win
                    if (getWin()) {
                        if (xTurn)
                            xWins++;
                        else
                            oWins++;
                        scores(); //update scores
                        reset(); //reset board
                    } else if (turns == 9) {
                        ties++;
                        scores();
                        reset();
                    } else
                        xTurn = !xTurn;

                    //increase turn count
                    turns++;
                }
            }
        });

        buttons[2][0].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(xTurn) {
                    //check if the button is empty
                    if (!buttons[2][0].getText().toString().equals(""))
                        return; //end the call if the spot is take

                    //set the players choice & check if they won
                    buttons[2][0].setText("X");

                    //check for win
                    if (getWin()) {
                        if (xTurn)
                            xWins++;
                        else
                            oWins++;
                        scores(); //update scores
                        reset(); //reset board
                    } else if (turns == 9) {
                        ties++;
                        scores();
                        reset();
                    } else
                        xTurn = !xTurn;

                    //increase turn count
                    turns++;
                }

                if(!xTurn){
                    //create rng for row & col
                    Random rngRow = new Random();
                    Random rngCol = new Random();

                    //make sure the computer's choice is not taken
                    while (buttons[rngRow.nextInt(3)][rngCol.nextInt(3)].getText().toString().equals("X")) {
                        rngRow = new Random();
                        rngCol = new Random();
                    }

                    //assign the computer choice
                    buttons[rngRow.nextInt(3)][rngCol.nextInt(3)].setText("O");

                    //check for win
                    if (getWin()) {
                        if (xTurn)
                            xWins++;
                        else
                            oWins++;
                        scores(); //update scores
                        reset(); //reset board
                    } else if (turns == 9) {
                        ties++;
                        scores();
                        reset();
                    } else
                        xTurn = !xTurn;

                    //increase turn count
                    turns++;
                }
            }
        });

        buttons[2][1].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(xTurn) {
                    //check if the button is empty
                    if (!buttons[2][1].getText().toString().equals(""))
                        return; //end the call if the spot is take

                    //set the players choice & check if they won
                    buttons[2][1].setText("X");

                    //check for win
                    if (getWin()) {
                        if (xTurn)
                            xWins++;
                        else
                            oWins++;
                        scores(); //update scores
                        reset(); //reset board
                    } else if (turns == 9) {
                        ties++;
                        scores();
                        reset();
                    } else
                        xTurn = !xTurn;

                    //increase turn count
                    turns++;
                }

                if(!xTurn){
                    //create rng for row & col
                    Random rngRow = new Random();
                    Random rngCol = new Random();

                    //make sure the computer's choice is not taken
                    while (buttons[rngRow.nextInt(3)][rngCol.nextInt(3)].getText().toString().equals("X")) {
                        rngCol = new Random();
                    }

                    //assign the computer choice
                    buttons[rngRow.nextInt(3)][rngCol.nextInt(3)].setText("O");

                    //check for win
                    if (getWin()) {
                        if (xTurn)
                            xWins++;
                        else
                            oWins++;
                        scores(); //update scores
                        reset(); //reset board
                    } else if (turns == 9) {
                        ties++;
                        scores();
                        reset();
                    } else
                        xTurn = !xTurn;

                    //increase turn count
                    turns++;
                }
            }
        });

        buttons[2][2].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(xTurn) {
                    //check if the button is empty
                    if (!buttons[2][2].getText().toString().equals(""))
                        return; //end the call if the spot is take

                    //set the players choice & check if they won
                    buttons[2][2].setText("X");

                    //check for win
                    if (getWin()) {
                        if (xTurn)
                            xWins++;
                        else
                            oWins++;
                        scores(); //update scores
                        reset(); //reset board
                    } else if (turns == 9) {
                        ties++;
                        scores();
                        reset();
                    } else
                        xTurn = !xTurn;

                    //increase turn count
                    turns++;
                }

                if(!xTurn){
                    //create rng for row & col
                    Random rngRow = new Random();
                    Random rngCol = new Random();

                    //make sure the computer's choice is not taken
                    while (buttons[rngRow.nextInt(3)][rngCol.nextInt(3)].getText().toString().equals("X")) {
                        rngRow = new Random();
                        rngCol = new Random();
                    }

                    //assign the computer choice
                    buttons[rngRow.nextInt(3)][rngCol.nextInt(3)].setText("O");

                    //check for win
                    if (getWin()) {
                        if (xTurn)
                            xWins++;
                        else
                            oWins++;
                        scores(); //update scores
                        reset(); //reset board
                    } else if (turns == 9) {
                        ties++;
                        scores();
                        reset();
                    } else
                        xTurn = !xTurn;

                    //increase turn count
                    turns++;
                }
            }
        });

        Button btnReset = findViewById(R.id.btn_reset);

        btnReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                xWins = 0;
                oWins = 0;
                ties = 0;
                reset();
                scores();
            }
        });
    }
}
