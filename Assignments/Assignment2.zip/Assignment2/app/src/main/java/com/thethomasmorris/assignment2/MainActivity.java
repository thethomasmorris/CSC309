package com.thethomasmorris.assignment2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    int numAdults, numChild;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //set title for action bar
        getSupportActionBar().setTitle("Bruno's Pizza");

        Button submit = findViewById( R.id.btn_submit );
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                submitOrder();
                Intent payIntent = new Intent(
                        getApplicationContext(), PaymentActivity.class);
                payIntent.setAction(Intent.ACTION_SEND);
                payIntent.putExtra("numA", numAdults);
                payIntent.putExtra("numC", numChild);
                startActivity( payIntent );
            }
        });
    }
    static final String SAVE_ADULTS = "adults";
    static final String SAVE_CHILDREN = "children";

    // save state or orientation change, etc.
    @Override
    public void onSaveInstanceState( Bundle savedInstanceState ) {
        super.onSaveInstanceState( savedInstanceState );

        // save the current input for adults or children
        savedInstanceState.putInt(SAVE_ADULTS, numAdults);
        savedInstanceState.putInt(SAVE_CHILDREN, numChild);

    }

    // restore information after an orientation change, etc.
    @Override
    public void onRestoreInstanceState( Bundle savedInstanceState ) {
        super.onRestoreInstanceState( savedInstanceState );

        numAdults = savedInstanceState.getInt(SAVE_ADULTS);
        numChild = savedInstanceState.getInt(SAVE_CHILDREN);
    }

    public void submitOrder() {
        //retrieve text from the text fields
        TextView texAdults = findViewById(R.id.tv_numAdults);
        String strAdults = texAdults.getText().toString();

        //check the contents of adults before parsing
        if(strAdults.equals(""))
            numAdults = 0;
        else
            numAdults = Integer.parseInt(strAdults);

        TextView texChild = findViewById(R.id.tv_numChild);
        String strChild = texChild.getText().toString();

        //check contents of child before parsing
        if(strChild.equals(""))
            numChild = 0;
        else
            numChild = Integer.parseInt(strChild);
    }
}


