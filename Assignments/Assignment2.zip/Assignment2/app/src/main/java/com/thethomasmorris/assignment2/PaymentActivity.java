package com.thethomasmorris.assignment2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class PaymentActivity extends AppCompatActivity {
    int totalA;
    int totalC;
    double tax, subTotal, total;
    String strCC, strCVC, strDate;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        //retrieve info from main activity
        Intent intent = getIntent();
        totalA = intent.getIntExtra("numA", 0);
        totalC = intent.getIntExtra("numC", 0);

        //set title for action bar
        getSupportActionBar().setTitle("Bruno's Pizza");

        getTotal();
        getText();

        Button submit = findViewById( R.id.btn_submit );
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int error = inputValid();
                if(error == 1)
                    Toast.makeText(getApplicationContext(),"Invalid CC!",Toast.LENGTH_SHORT).show();
                else if(error == 2)
                    Toast.makeText(getApplicationContext(),"Invalid CVC!",Toast.LENGTH_SHORT).show();
                else if(error == 3)
                    Toast.makeText(getApplicationContext(),"Invalid Date! MM/DD/YYYY",Toast.LENGTH_SHORT).show();
                else {
                    Toast.makeText(getApplicationContext(), "Payment Successful!", Toast.LENGTH_SHORT).show();
                    reset();
                }
            }
        });
    }

    static final String SAVE_SUB = "subTotal";
    static final String SAVE_TAX = "tax";
    static final String SAVE_TOTAL = "total";
    static final String SAVE_CC = "cc";
    static final String SAVE_CVC = "cvc";
    static final String SAVE_DATE = "date";

    // save state or orientation change, etc.
    @Override
    public void onSaveInstanceState( Bundle savedInstanceState ) {
        super.onSaveInstanceState( savedInstanceState );

        // save the current input
        savedInstanceState.putDouble(SAVE_SUB, subTotal);
        savedInstanceState.putDouble(SAVE_TAX, tax);
        savedInstanceState.putDouble(SAVE_TOTAL, total);
        savedInstanceState.putString(SAVE_CC, strCC);
        savedInstanceState.putString(SAVE_CVC, strCVC);
        savedInstanceState.putString(SAVE_DATE, strDate);
    }

    // restore information after an orientation change, etc.
    @Override
    public void onRestoreInstanceState( Bundle savedInstanceState ) {
        super.onRestoreInstanceState( savedInstanceState );

        subTotal = savedInstanceState.getDouble(SAVE_SUB);
        tax = savedInstanceState.getDouble(SAVE_TAX);
        total = savedInstanceState.getDouble(SAVE_TOTAL);
        strCC = savedInstanceState.getString(SAVE_CC);
        strCVC = savedInstanceState.getString(SAVE_CVC);
        strDate = savedInstanceState.getString(SAVE_DATE);
    }

    public void getTotal(){
        //find their total purchase amount
        subTotal = (totalA*29.95)+(totalC*15.95);
        subTotal = Math.round(subTotal*100.0)/100.0;
        tax = subTotal*0.06;
        tax = Math.round(tax*100.0)/100.0;
        total = subTotal+tax;
        total = Math.round(total*100.0)/100.0;

        //apply total purchase amount to the screen
        TextView texSub = findViewById(R.id.tv_subTotal);
        texSub.setText("Subtotal: "+subTotal);

        TextView texTax = findViewById(R.id.tv_tax);
        texTax.setText(" + Tax: "+tax);

        TextView texTotal = findViewById(R.id.tv_total);
        texTotal.setText(" = Total: "+total);
    }
    public void getText(){
        //get the text from the text view
        TextView texCC = findViewById(R.id.tv_ccNum);
        strCC = texCC.getText().toString();
        TextView texCVC = findViewById(R.id.tv_cvcNum);
        strCVC = texCVC.getText().toString();
        TextView texDate = findViewById(R.id.tv_date);
        strDate = texDate.getText().toString();
    }
    public int inputValid(){
        getText();
        //check cc number for correct length
        if(strCC.length() < 16)
            return 1;

        //check cvc for correct length
        if(strCVC.length() < 3)
            return 2;

        //check the date for correct formatting and length
        if(strDate.length() < 10)
            return 3;
        if((strDate.charAt(2) != '/') && (strDate.charAt(5) != '/'))
            return 3;
        for (int i = 0; i < strDate.length(); i++) {
            if(i==2 || i==5)
                continue;
            else
                if (!Character.isDigit(strDate.charAt(i)))
                    return 3;
        }
        return 4;
    }

    public void reset(){
        Intent mainIntent = new Intent(
                getApplicationContext(), MainActivity.class);
        mainIntent.setAction(Intent.ACTION_SEND);
        startActivity( mainIntent );
    }
}
