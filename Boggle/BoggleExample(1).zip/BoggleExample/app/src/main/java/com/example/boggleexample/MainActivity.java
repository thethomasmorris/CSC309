package com.example.boggleexample;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    int[][] diceLettersNew = {
            {1,1,5,5,7,14},                 // AAEEGN
            {5,12,18,20,20,25},             // ELRTTY
            {1,15,15,20,20,23},             // AOOTTW
            {1,2,2,10,15,15},               // ABBJOO
            {5,8,18,20,22,23},              // EHRTVW
            {3,9,13,15,20,21},              // CIMOTU
            {4,9,19,20,20,25},              // DISTTY
            {5,9,15,19,19,20},              // EIOSST
            {4,5,12,18,22,25},              // DELRVY
            {1,3,8,15,16,19},               // ACHOPS
            {8,9,13,14,17,21},              // HIMNQU
            {5,5,9,14,19,21},               // EEINSU
            {5,5,7,8,14,23},                // EEGHNW
            {1,6,6,11,16,19},               // AFFKPS
            {8,12,14,14,18,26},             // HLNNRZ
            {4,5,9,12,18,24} };             // DEILRX

    // current dice
    DieFace[] curBoard = new DieFace[16];

    // list of all words the user has found
    ArrayList<String> foundWords = new ArrayList<>();
    Button submit;

    // word the user is currently entering
    ArrayList<DieFace> curWord = new ArrayList<>();

    Random rng = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // display the letters
        curBoard[0] = new DieFace( R.id.btn_letter_11, 0, this );
        curBoard[1] = new DieFace( R.id.btn_letter_12, 1, this );
        curBoard[2] = new DieFace( R.id.btn_letter_13, 2, this );
        curBoard[3] = new DieFace( R.id.btn_letter_14, 3, this );
        curBoard[4] = new DieFace( R.id.btn_letter_21, 4, this );
        curBoard[5] = new DieFace( R.id.btn_letter_22, 5, this );
        curBoard[6] = new DieFace( R.id.btn_letter_23, 6, this );
        curBoard[7] = new DieFace( R.id.btn_letter_24, 7, this );
        curBoard[8] = new DieFace( R.id.btn_letter_31, 8, this );
        curBoard[9] = new DieFace( R.id.btn_letter_32, 9, this );
        curBoard[10] = new DieFace( R.id.btn_letter_33, 10, this );
        curBoard[11] = new DieFace( R.id.btn_letter_34, 11, this );
        curBoard[12] = new DieFace( R.id.btn_letter_41, 12, this );
        curBoard[13] = new DieFace( R.id.btn_letter_42, 13, this );
        curBoard[14] = new DieFace( R.id.btn_letter_43, 14, this );
        curBoard[15] = new DieFace( R.id.btn_letter_44, 15, this );

        submit = findViewById( R.id.btn_submit );
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                submitWord();
            }
        });

        // prepare our help activity button
        Button helpButton = findViewById( R.id.btn_help );
        helpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent helpIntent = new Intent(
                        getApplicationContext(), HelpActivity.class );
                startActivity( helpIntent );
            }
        });
        // start a new game
        newGame();
    }

    // names for saved values
    static final String SAVE_LETTERS = "letters";
    static final String SAVE_USED = "isused";
    static final String SAVE_WORDS = "words";
    static final String SAVE_CURWORD = "curword";

    // save state or orientation change, etc.
    @Override
    public void onSaveInstanceState( Bundle savedInstanceState ) {
        super.onSaveInstanceState( savedInstanceState );

        // save the current letters on the board
        int[] letterIndexValues = new int[16];
        boolean[] isUsedValues = new boolean[16];

        for( int i=0; i<16; i++ ) {
            letterIndexValues[i] = curBoard[i].getLetterIndex();
            isUsedValues[i] = curBoard[i].getIsUsed();
        }
        savedInstanceState.putIntArray( SAVE_LETTERS, letterIndexValues );
        savedInstanceState.putBooleanArray( SAVE_USED, isUsedValues );

        // save the list of words the user found
        savedInstanceState.putStringArrayList( SAVE_WORDS, foundWords );

        // save the list of buttons used on the current (partial) word
        int[] curWordButtons = new int[curWord.size()];
        for( int i=0; i<curWord.size(); i++ ) {
            curWordButtons[i] = curWord.get(i).getPositionIndex();
        }
        savedInstanceState.putIntArray( SAVE_CURWORD, curWordButtons );
    }

    // restore information after an orientation change, etc.
    @Override
    public void onRestoreInstanceState( Bundle savedInstanceState ) {
        super.onRestoreInstanceState( savedInstanceState );

        int[] letterIndexValues = savedInstanceState.getIntArray( SAVE_LETTERS );
        boolean[] isUsedValues = savedInstanceState.getBooleanArray( SAVE_USED );

        // restore the saved letter, note if it had been used
        for( int i=0; i<16; i++ ) {
            curBoard[i].setLetterIndex( letterIndexValues[i] );
            curBoard[i].setIsUsed( isUsedValues[i] );
        }

        // get the list of found words
        foundWords = savedInstanceState.getStringArrayList( SAVE_WORDS );

        // restore the current (partial) word
        int[] curWordButtons = savedInstanceState.getIntArray( SAVE_CURWORD );
        curWord.clear();        // a little paranoia here
        for( int i=0; i<curWordButtons.length; i++ ) {
            curWord.add( curBoard[ curWordButtons[i] ] );
        }
        updateCurrentWordButton();

        // copy it to the textview
        updateFoundWordDisplay();
    }

    // start a new game
    public void newGame() {
        ArrayList<Integer> displayLetters = new ArrayList<>();
        // select which letters will appear
        for( int i=0; i<16; i++ ) {
            // which side of die __ will be face up?
            displayLetters.add(i, diceLettersNew[i][rng.nextInt(6)] );
        }
        // mix up the cubes
        Collections.shuffle(displayLetters);

        // set the letter and not used
        for( int i=0; i<16; i++ ) {
            curBoard[i].setLetterIndex( displayLetters.get(i) );
            curBoard[i].setIsUsed( false );
        }
    }

    // update the current wrod button
    protected void updateCurrentWordButton() {
        Button wordSubmit = findViewById( R.id.btn_submit );

        if ( curWord.size() == 0 ) {
            // no current word
            // reset the submit button
            wordSubmit.setText( "Submit" );
            return;
        }

        // construct the current word
        String dispWord = "";
        for( int i=0; i<curWord.size(); i++ )
            dispWord += curWord.get(i).getLetter();

        // display it on the word submit button
        wordSubmit.setText( dispWord );
    }

    // the user just pressed a button
    public void letterPressed( DieFace curLetter ) {
        curWord.add( curLetter );

        updateCurrentWordButton();
    }

    // update the displayed list of found words
    // assmes that foundWords has the current list of words
    protected void updateFoundWordDisplay() {
        // build the list of words the user has found
        String wordList = "";
        for( int i=0; i<foundWords.size(); i++ ) {
            wordList += foundWords.get(i) + " ";
        }

        // display the list of words
        TextView displayWordList = findViewById( R.id.tv_wordlist );
        displayWordList.setText( wordList );
    }

    // user is ready to submit a word
    protected void submitWord() {
        // check against word list (--later--)

        // construct the current word
        String dispWord = "";
        for( int i=0; i<curWord.size(); i++ )
            dispWord += curWord.get(i).getLetter();

        // note we found a word
        foundWords.add( dispWord );

        // show it to the user
        updateFoundWordDisplay();

        // reset the list
        curWord.clear();

        // reset the submit button
        submit.setText( "Submit" );
    }
}
