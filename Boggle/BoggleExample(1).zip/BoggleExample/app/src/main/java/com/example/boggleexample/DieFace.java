package com.example.boggleexample;

import android.view.View;
import android.widget.Button;

public class DieFace {
    int letterIndex;
    int positionIndex;      // where is this button (0..15)
    Button myButton;
    boolean isUsed;
    MainActivity mainActivity;

    // letters for each face
    protected static String [] faceLetters = { " ",
            "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M",
            "N", "O", "P", "QU", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" };

    // constructor
    public DieFace( int buttonID, int posId, MainActivity mActivity ) {
        // what letter are we displaying?
        letterIndex = 0;

        // where are we on the board?
        positionIndex = posId;

        // save link
        mainActivity = mActivity;

        // get the button object
        myButton = mainActivity.findViewById( buttonID );
        //myButton.setText( faceLetters[letterIndex] );

        // respond to a click
        myButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // send it back to the main activity
                mainActivity.letterPressed(DieFace.this);
            }
        });

        // not currently used
        isUsed = false;
    }

    // get the current letter
    public String getLetter() { return faceLetters[letterIndex];}

    // which button is this?
    public int getPositionIndex() { return positionIndex; }

    public int getLetterIndex() { return letterIndex; }
    public void setLetterIndex( int li ) {
        letterIndex = li;
        myButton.setText( faceLetters[letterIndex] );
    }
    public boolean getIsUsed() { return isUsed; }
    public void setIsUsed( boolean is ) { isUsed = is; }
}
